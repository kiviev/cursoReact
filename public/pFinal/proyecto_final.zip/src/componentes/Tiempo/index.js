import React from 'react';
import ReactDOM from 'react-dom';
// import './index.css';
import Tiempo from './Tiempo';
import registerServiceWorker from './registerServiceWorker';

ReactDOM.render(<Tiempo />, document.getElementById('root'));
registerServiceWorker();
