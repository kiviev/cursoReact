

const CONFIG = {
	apiWeather : {
		url : 'https://api.openweathermap.org',
		data : '/data',
		version : '/2.5',
		type : '/weather',
		appid : '5aa82f6c6baaebeb11c9d322e2cf6927',
		imgIconPath : '/img/w'
	}
}


export default CONFIG;