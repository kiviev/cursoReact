import React, { Component } from 'react';
// components
import {Weather} from './components/index';

class Tiempo extends Component {


  render() {
    return (
            <Weather />
          
    );
  }
}

export default Tiempo;
