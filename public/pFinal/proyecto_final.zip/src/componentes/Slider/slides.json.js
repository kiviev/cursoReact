const slidesData = [
	{
		"src" : "https://i.ytimg.com/vi/_tQfUK335xk/maxresdefault.jpg",
		"alt" :  "Lago",
		'label' : 'label custom',
		'desc'	:'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Harum atque cupiditate facilis autem labore similique quia consequatur earum minus provident suscipit quo, quae explicabo ab quisquam. Ad ex ipsum ut.'
	},
	{
		"src" : "http://www.paisajesimagenes.com/wp-content/uploads/fotos-de-paisajes.jpg",
		"alt" :  "Arroyo",
		'label' : 'label custom',
		'desc'	:'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatem, totam minus aliquam repudiandae omnis, quia sit maiores a cupiditate adipisci placeat amet blanditiis dolor, harum, cum accusamus fugiat. Sunt, aliquid!'
	},
	{
		"src" : "http://1.bp.blogspot.com/-5eD4rSBm7XU/VYIEZ8SK9JI/AAAAAAAAB0w/BbcUVXzUxJY/s1600/colores_nocturnos-1024x768.jpg",
		"alt" :  "Luna",
		'label' : 'label custom',
		'desc'	:'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloremque iste excepturi perferendis, magnam velit doloribus tempore voluptatibus sapiente a aperiam dolorem nemo in necessitatibus nisi dolore officia enim hic ex?'
	},
	{
		"src" : "https://www.hola.com/imagenes/viajes/2016021083709/pueblos-montana-bonitos-espana/0-351-436/a_canga-a.jpg",
		"alt" :  "Puente",
		'label' : 'label custom',
		'desc'	:'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repellendus iste amet recusandae accusamus dicta quos culpa quibusdam deleniti id ipsam, maxime, officiis laboriosam explicabo odit pariatur necessitatibus, quis natus minus.'
	},
	{
		"src" : "https://s-media-cache-ak0.pinimg.com/originals/05/33/b4/0533b49b75ba4368af88fe341e7384c5.jpg",
		"alt" :  "Margaritas",
		'label' : 'label custom',
		'desc'	:'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Temporibus odit molestias eligendi veritatis nostrum quis fugiat illo iusto quidem eaque voluptatibus aliquam tenetur minus ea enim, quisquam, incidunt voluptatem magnam.'
	},
	{
		"src" : "https://kdeotero.files.wordpress.com/2015/05/fondos-pantalla-paisajes-hermosos-bonitos-naturales-escritorio-fotografias-hd-wallpaper-imagenes-fotos-3d-tailandia-playas-bonito-viajar-1.jpg",
		"alt" :  "Barca",
		'label' : 'label custom',
		'desc'	:'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cum vitae a eius consequatur. Unde esse, minus, fuga ipsam modi commodi sapiente minima quisquam voluptatum magni fugit quaerat tenetur voluptatem qui!'
	}
]

export default slidesData;