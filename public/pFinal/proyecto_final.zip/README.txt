
Buenas, el punto del ejercicio que dice:

● En la tercera pestaña se hará uso de Foundation para realizar una sencilla interfaz. Esta
deberá contener, al menos, cinco tipos distintos de elementos.

No lo he hecho con Foundation, sino con Bootstrap, lo he hecho así porque al instalar el slider de React-Slick, no se que pasaba pero se rompía, supongo que como usé bootstrap para la parte del TODO habría algúna incompatibilidad.  Lo he cambiado por el slider (Carusel le llaman) de Bootstrap.

He añadido un componente Home aunque no hace nada.

Esto hace qe no estén ordenadas segun las especificaciones del ejercicio es decir:

pestañas:
1-home
2-todo,
3-wheather
4-slider

Me sale un error que no impide funcionalidad que no he sabido reparar
"index.js:2177 Warning: validateDOMNesting(...): <a> cannot appear as a descendant of <a>."

¿Si puede ser, me podría explicar porqué salta este error y como solucionarlo?
Muchas gracias
Un saludo

Paco Alba