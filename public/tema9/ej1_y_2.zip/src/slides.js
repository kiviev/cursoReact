const slidesData = [
	{
		"src" : "https://i.ytimg.com/vi/_tQfUK335xk/maxresdefault.jpg",
		"alt" :  "Lago"
	},
	{
		"src" : "http://www.paisajesimagenes.com/wp-content/uploads/fotos-de-paisajes.jpg",
		"alt" :  "Arroyo"
	},
	{
		"src" : "http://1.bp.blogspot.com/-5eD4rSBm7XU/VYIEZ8SK9JI/AAAAAAAAB0w/BbcUVXzUxJY/s1600/colores_nocturnos-1024x768.jpg",
		"alt" :  "Luna"
	},
	{
		"src" : "https://www.hola.com/imagenes/viajes/2016021083709/pueblos-montana-bonitos-espana/0-351-436/a_canga-a.jpg",
		"alt" :  "Puente"
	},
	{
		"src" : "https://s-media-cache-ak0.pinimg.com/originals/05/33/b4/0533b49b75ba4368af88fe341e7384c5.jpg",
		"alt" :  "Margaritas"
	},
	{
		"src" : "https://kdeotero.files.wordpress.com/2015/05/fondos-pantalla-paisajes-hermosos-bonitos-naturales-escritorio-fotografias-hd-wallpaper-imagenes-fotos-3d-tailandia-playas-bonito-viajar-1.jpg",
		"alt" :  "Barca"
	}
]

export default slidesData;